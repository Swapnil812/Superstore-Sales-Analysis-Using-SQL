-- =========================================================
-- SUPERSTORE SALES ANALYSIS PROJECT
-- =========================================================

-- In this project we will:
-- 1. Import the Superstore dataset
-- 2. Normalize the data into separate tables
-- 3. Use Subqueries
-- 4. Use CTEs
-- 5. Use Window Functions
-- 6. Solve business-related SQL queries



-- =========================================================
-- STEP 1: CREATE DATABASE
-- =========================================================

-- Creating a new database for this project
CREATE DATABASE superstore_db;
-- Selecting the database so all operations happen inside it

USE superstore_db;

SET GLOBAL local_infile = 1;
SHOW VARIABLES LIKE 'local_infile';

-- =========================================================
-- STEP 2: CREATE RAW TABLE
-- =========================================================

-- This table stores the complete original dataset
-- exactly as it comes from the CSV file
CREATE TABLE superstore_raw (

    row_id INT,
    order_id VARCHAR(50),

    order_date DATE,
    ship_date DATE,

    ship_mode VARCHAR(100),

    customer_id VARCHAR(50),
    customer_name VARCHAR(100),
    segment VARCHAR(50),

    country VARCHAR(100),
    city VARCHAR(100),
    state VARCHAR(100),
    postal_code VARCHAR(20),
    region VARCHAR(50),

    product_id VARCHAR(50),
    category VARCHAR(100),
    sub_category VARCHAR(100),
    product_name VARCHAR(255),

    sales DECIMAL(10,2),
    quantity INT,
    discount DECIMAL(5,2),
    profit DECIMAL(10,2)
);

TRUNCATE TABLE superstore_raw;
-- =========================================================
-- STEP 3: IMPORT CSV FILE
-- =========================================================

-- Loading the CSV file into MySQL

-- CHARACTER SET latin1 is used because some product names
-- contain special characters that may not load correctly
-- with UTF-8 encoding
LOAD DATA LOCAL INFILE 'C:/Users/swapn/Desktop/Celebal Technologies/Week 3/archive week 3/Sample - Superstore.csv'
INTO TABLE superstore_raw
CHARACTER SET latin1
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 ROWS
(
    row_id,
    order_id,
    @order_date,
    @ship_date,
    ship_mode,
    customer_id,
    customer_name,
    segment,
    country,
    city,
    state,
    postal_code,
    region,
    product_id,
    category,
    sub_category,
    product_name,
    sales,
    quantity,
    discount,
    profit
)
SET

-- Converting the dates from text format into SQL DATE format
order_date = STR_TO_DATE(@order_date, '%m/%d/%Y'),
ship_date = STR_TO_DATE(@ship_date, '%m/%d/%Y');
-- =========================================================
-- STEP 4: CHECK WHETHER DATA IMPORTED CORRECTLY
-- =========================================================

-- Counting total rows imported into the table
SELECT COUNT(*) FROM superstore_raw;
-- =========================================================
-- STEP 5: CREATE CUSTOMERS TABLE
-- =========================================================

-- Creating a separate customer table

-- DISTINCT removes duplicate customer records

-- This is done to normalize the database
-- and make it more organized
CREATE TABLE customers AS
SELECT DISTINCT
    customer_id,
    customer_name,
    segment,
    country,
    city,
    state,
    postal_code,
    region
FROM superstore_raw;
-- =========================================================
-- STEP 6: CREATE PRODUCTS TABLE
-- =========================================================

-- Creating a separate products table
-- to store unique product details

CREATE TABLE products AS

SELECT DISTINCT

    product_id,
    category,
    sub_category,
    product_name

FROM superstore_raw;



-- Viewing products table

SELECT * FROM products;



-- =========================================================
-- STEP 7: CREATE ORDERS TABLE
-- =========================================================

-- This table stores all order-related information

CREATE TABLE orders AS

SELECT DISTINCT

    order_id,
    order_date,
    ship_date,
    ship_mode,

    customer_id,
    product_id,

    sales,
    quantity,
    discount,
    profit

FROM superstore_raw;



-- Viewing orders table

SELECT * FROM orders;



-- =========================================================
-- STEP 8: SUBQUERY
-- FIND ORDERS WITH ABOVE-AVERAGE SALES
-- =========================================================

-- The inner query calculates average sales

-- The outer query returns only those orders
-- where sales are greater than the average sales

SELECT *

FROM orders

WHERE sales > (

    SELECT AVG(sales)

    FROM orders
);



-- =========================================================
-- STEP 9: HIGHEST ORDER FOR EACH CUSTOMER
-- OPTIMIZED VERSION
-- =========================================================

-- Finding the highest order placed by every customer

-- First calculating maximum sales for each customer

WITH max_sales AS (

    SELECT
        customer_id,
        MAX(sales) AS highest_sales

    FROM orders

    GROUP BY customer_id
)

-- Joining back with orders table
-- to get complete order details

SELECT

    o.customer_id,
    o.order_id,
    o.sales

FROM orders o

JOIN max_sales m

ON o.customer_id = m.customer_id

AND o.sales = m.highest_sales;


-- =========================================================
-- STEP 10: CTE (COMMON TABLE EXPRESSION)
-- =========================================================

-- CTE makes complex queries easier to read

-- Here we calculate the total sales
-- generated by each customer

WITH customer_sales AS (

    SELECT
        customer_id,
        SUM(sales) AS total_sales

    FROM orders

    GROUP BY customer_id
)

SELECT *
FROM customer_sales
ORDER BY total_sales DESC;


-- =========================================================
-- STEP 11: WINDOW FUNCTION - ROW_NUMBER()
-- =========================================================

-- ROW_NUMBER gives ranking within each customer group

-- PARTITION BY separates data customer-wise

-- Highest sales order for a customer gets row number 1

SELECT

    customer_id,
    order_id,
    sales,

    ROW_NUMBER() OVER (

        PARTITION BY customer_id

        ORDER BY sales DESC

    ) AS row_num

FROM orders;



-- =========================================================
-- STEP 12: WINDOW FUNCTION - RANK()
-- =========================================================

-- Ranking customers based on total sales

-- Customer with highest sales gets highest rank

SELECT

    customer_id,

    SUM(sales) AS total_sales,

    RANK() OVER (

        ORDER BY SUM(sales) DESC

    ) AS sales_rank

FROM orders

GROUP BY customer_id;



-- =========================================================
-- STEP 13: JOIN + CTE + WINDOW FUNCTION
-- =========================================================

-- JOIN connects customer and order tables

-- CTE calculates total customer sales

-- RANK() ranks customers based on sales

WITH customer_total_sales AS (

    SELECT

        c.customer_id,
        c.customer_name,

        SUM(o.sales) AS total_sales

    FROM customers c

    JOIN orders o

    ON c.customer_id = o.customer_id

    GROUP BY c.customer_id, c.customer_name
)

SELECT

    customer_id,
    customer_name,
    total_sales,

    RANK() OVER (

        ORDER BY total_sales DESC

    ) AS customer_rank

FROM customer_total_sales;



-- =========================================================
-- STEP 14: TOP 10 CUSTOMERS
-- =========================================================

-- Finding customers who generated the highest sales

SELECT

    c.customer_name,

    SUM(o.sales) AS total_sales

FROM customers c

JOIN orders o

ON c.customer_id = o.customer_id

GROUP BY c.customer_name

ORDER BY total_sales DESC

LIMIT 10;



-- =========================================================
-- STEP 15: LOWEST SALES CUSTOMERS
-- =========================================================

-- Finding customers with the lowest sales contribution

SELECT

    c.customer_name,

    SUM(o.sales) AS total_sales

FROM customers c

JOIN orders o

ON c.customer_id = o.customer_id

GROUP BY c.customer_name

ORDER BY total_sales ASC

LIMIT 10;



-- =========================================================
-- STEP 16: CUSTOMERS WITH ONLY ONE ORDER
-- =========================================================

-- Finding customers who placed only one order

SELECT

    customer_id,

    COUNT(order_id) AS total_orders

FROM orders

GROUP BY customer_id

HAVING COUNT(order_id) = 1;



-- =========================================================
-- STEP 17: CUSTOMERS ABOVE AVERAGE SALES
-- =========================================================

-- First calculating total sales for each customer

-- Then comparing customer sales against
-- average customer sales

WITH customer_avg AS (

    SELECT

        customer_id,

        SUM(sales) AS total_sales

    FROM orders

    GROUP BY customer_id
)

SELECT *

FROM customer_avg

WHERE total_sales > (

    SELECT AVG(total_sales)

    FROM customer_avg
);



-- =========================================================
-- STEP 18: REGION-WISE SALES ANALYSIS
-- =========================================================

-- Finding total sales generated by each region

SELECT

    c.region,

    SUM(o.sales) AS total_sales

FROM customers c

JOIN orders o

ON c.customer_id = o.customer_id

GROUP BY c.region

ORDER BY total_sales DESC;



-- =========================================================
-- STEP 19: MOST PROFITABLE PRODUCTS
-- =========================================================

-- Finding products generating the highest profit

SELECT

    p.product_name,

    SUM(o.profit) AS total_profit

FROM products p

JOIN orders o

ON p.product_id = o.product_id

GROUP BY p.product_name

ORDER BY total_profit DESC

LIMIT 10;



-- =========================================================
-- STEP 20: CATEGORY-WISE SALES
-- =========================================================

-- Calculating total sales for each product category

SELECT

    p.category,

    SUM(o.sales) AS total_sales

FROM products p

JOIN orders o

ON p.product_id = o.product_id

GROUP BY p.category

ORDER BY total_sales DESC;